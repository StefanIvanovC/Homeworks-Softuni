﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarDealer.DataTransferObjects.Input
{
    class CustomerInputModel
    {
    }
}

